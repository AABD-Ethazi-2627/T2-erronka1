# CG34: piloto CPU/CUDA en Kalista

**Decisión medida: mantener CPU para el pool principal.** El piloto no alcanza
la mejora global de tiempo del 25% fijada para ampliar el uso de GPU. Este
resultado depende del tamaño, las versiones, los parámetros y el flujo medidos.

## Datos, implementación y recursos

Manifiesto `d881aa24d43a1f44e98956c37a4e88cacb21989a1fe0c205ed9e8d67aa72187b`;
código de ajuste `e644737`. Ocho procesos completados sin timeout: dos repeticiones
CPU/CUDA de CatBoost depth 4 sin pesos y XGBoost depth 3 con ratio de clases por fit.
Se usan las mismas 2.488 filas de ajuste y 1.245 de evaluación interna, con 43
positivos en estas últimas. Todas pertenecen a las 5.600 train originales.
El piloto no selecciona modelos, configuraciones ni umbrales del análisis primario.

Windows; Ryzen 5 7600X, 6 núcleos y 12 hilos; RTX 5070 Ti de 16 GiB; driver 630.20.
Python 3.12.10, sklearn 1.5.0, CatBoost 1.2.10 y XGBoost 3.1.3.
`xgboost.build_info()` declara `USE_CUDA=true` y CUDA 12.5. La versión máxima
anunciada por el controlador difiere del runtime de la biblioteca. El entrenamiento
CUDA se ejecutó realmente. FedoraLinux-43 en WSL ve la misma GPU; sus bibliotecas
no se probaron y no se modificó su configuración.

Preparación, fit y predicción se cronometran por separado. El fit de la tabla
excluye preparación; esta figura en el JSON. Se fija un hilo por biblioteca.
El total de proceso incluye importación, recarga, el primer lote y 50 mediciones
warm de una fila. Las repeticiones son procesos distintos: no acreditan caché
fría/caliente de todo el sistema.

| Modelo / backend | Fit 1 / fit 2 (s) | Total de proceso 1 / 2 (s) | Predicción del lote 1 / 2 (s) |
|---|---:|---:|---:|
| CatBoost CPU | 10.450 / 10.866 | 12.257 / 12.580 | 0.00383 / 0.00338 |
| CatBoost CUDA | 21.166 / 8.546 | 22.939 / 10.369 | 0.00434 / 0.00359 |
| XGBoost CPU | 0.159 / 0.149 | 2.068 / 1.842 | 0.00514 / 0.00749 |
| XGBoost CUDA | 63.644 / 31.418 | 71.668 / 33.832 | 5.66929 / 0.02876 |

CatBoost predice en CPU en ambos casos; CUDA se usa para entrenar. XGBoost conserva
`device=cuda` y recibe la matriz CPU del pipeline. Registró el aviso
`Falling back to prediction using DMatrix due to mismatched devices`.
La predicción medida incluye esa adaptación. Se conserva el aviso y no se añade
otro pipeline para presentar una aceleración que el flujo actual no alcanza.

RSS máximo observado por muestreo: CatBoost CPU, unos 162 MiB; CUDA, 528 MiB;
XGBoost CPU, 267 MiB; CUDA, 817 MiB. La memoria GPU total alcanzó unos 5,44 GiB
con CatBoost, incluyendo el escritorio. El incremento respecto al inicio del
proceso quedó por debajo de 4 GiB. WDDM no permite atribuir ese total como VRAM
privada exacta del experimento. Cada `accounting.json` conserva baseline y máximos.

## Diferencias numéricas y de errores

La tolerancia de recarga es `atol=1e-12, rtol=0` para el **mismo modelo**.
La comparación CPU/CUDA contrasta implementaciones diferentes. CatBoost fija
Plain/Logloss, Bernoulli/subsample 1, border_count 128, L2, random_strength 0,
leaf_estimation_iterations 10 y one_hot_max_size 2, además del catálogo.

| Modelo | Máxima diferencia de score CPU/CUDA | Discrepancias en 0.15 / 1.245 | CPU TP / FN / FP | CUDA TP / FN / FP |
|---|---:|---:|---:|---:|
| CatBoost | 0.330523 | 11 | 38 / 5 / 32 | 36 / 7 / 27 |
| XGBoost | 0.101117 | 5 | 41 / 2 / 61 | 41 / 2 / 58 |

Ambas repeticiones produjeron los mismos resultados respectivos observados.
Esto no garantiza determinismo de CatBoost en GPU: su documentación señala la
variación posible en las sumas de coma flotante.
[CatBoost: entrenamiento en GPU](https://catboost.ai/docs/en/features/training-on-gpu).
Los recuentos son diagnóstico del piloto; no son resultados del selector nested
ni de la validación reutilizada. La aceleración de XGBoost depende también del
movimiento de datos y del backend.
[XGBoost 3.1: GPU](https://xgboost.readthedocs.io/en/release_3.1.0/gpu/index.html).

Los scores XGBoost nativos son float32: el informe los decodifica en ese dtype
antes de promoverlos a float64. La verificación de recarga contrasta esa lectura
con los artefactos propios. Los originales se conservan.

GPU contabilizada: **138,808 s**, equivalentes a 0,0386 GPU-h; se carga toda la
vida de los cuatro procesos CUDA. La suma de los ocho procesos ronda 167,6 s,
por debajo de los 600 s del piloto. CPU se registra por separado. El estudio
mantiene sus techos de 14 CPU-h y 2 GPU-h.

## Evidencia y revisión

Raw local: `D:/cnc-guard-research/study-20261023-v2/units/`, `pilot-summary.json`,
`pilot-comparisons.json` y `hardware.json`. Consola:
`D:/cnc-guard-research/pilot-v2-console.log`.

El informe completo publicará los artefactos y sus hashes. Medición y revisión
propia del agente; revisión independiente, CI, integración, decisión PM y
validación industrial permanecen diferenciadas.
